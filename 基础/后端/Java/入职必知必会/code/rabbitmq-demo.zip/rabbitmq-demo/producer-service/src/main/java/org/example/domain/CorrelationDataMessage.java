package org.example.domain;

import lombok.Data;
import org.springframework.amqp.rabbit.connection.CorrelationData;
import org.springframework.amqp.rabbit.core.RabbitTemplate;

@Data
public class CorrelationDataMessage extends CorrelationData {

    private String exchangeName;

    private String routingKey;

    private Object msg;

}
