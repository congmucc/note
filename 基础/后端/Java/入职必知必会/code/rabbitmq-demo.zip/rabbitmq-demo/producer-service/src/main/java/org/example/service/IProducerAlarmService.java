package org.example.service;

import java.util.Map;

public interface IProducerAlarmService {
    String producerAlarmInfo(Map<String,Object> map);

    String producerConfirmAlarmInfo(Map<String,Object> map);
}
