package org.example.constant;

public class RabbitMqConstant {

    public static final String EXCHANGE_NAME = "amq.topic";

    public static final String QUEUE_NAME = "alarm.data.topic.queue";

    public static final String CONFIRM_ALARM_QUEUE_NAME = "alarm.confirm.data.topic.queue";

    public static final String ALARM_ROUTING_KEY = "server.event.#";

    public static final String CONFIRM_ALARM_ROUTING_KEY = "server.event_confirm.#";
}
