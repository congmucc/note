package org.example;

import org.example.service.IProducerAlarmService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.*;

/**
 * Unit test for simple App.
 */
@SpringBootTest
public class ProducerAppTest {
 /*   @Autowired
    private RabbitTemplate rabbitTemplate;

    @Autowired
    private AlarmConfirmCallBack alarmConfirmCallBack;

    @PostConstruct
    public void init(){
        rabbitTemplate.setConfirmCallback(alarmConfirmCallBack);
    }

    private static String EXCHANGE_NAME="amq.topic222";

    private static String ALARM_ROUTING_KEY="server.event.#";

    private static String CONFIRM_ALARM_ROUTING_KEY="server.event_confirm.#";*/

    @Autowired
    private IProducerAlarmService producerAlarmService;
    @Test
    void producerAlarmMsg() {
        Map<String,Object> map= new HashMap<>();
        map.put("alarmId",1);
        map.put("alarmTime","2024 12-31 15:30:58");
        map.put("alarmInfo","拙野驾到，统统闪开！");
        producerAlarmService.producerAlarmInfo(map);
    }



    @Test
    void producerConfirmAlarmMsg() {
        Map<String,Object> map= new HashMap<>();
        List<Integer> list = Arrays.asList(1,2,3);
        map.put("alarmId",list);
        producerAlarmService.producerConfirmAlarmInfo(map);
    }


}

