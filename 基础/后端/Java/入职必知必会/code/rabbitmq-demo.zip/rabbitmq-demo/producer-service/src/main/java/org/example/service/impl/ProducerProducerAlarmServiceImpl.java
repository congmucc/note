package org.example.service.impl;

import org.example.config.AlarmConfirmCallBack;
import org.example.domain.CorrelationDataMessage;
import org.example.service.IProducerAlarmService;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.Map;
import java.util.UUID;

@Service
public class ProducerProducerAlarmServiceImpl implements IProducerAlarmService {

    private static String EXCHANGE_NAME="amq.topic";

    private static String ALARM_ROUTING_KEY="server.event.#";

    private static String CONFIRM_ALARM_ROUTING_KEY="server.event_confirm.#";

    @Autowired
    private RabbitTemplate rabbitTemplate;
    @Autowired
    private AlarmConfirmCallBack alarmConfirmCallBack;

    @PostConstruct
    public void init(){
        rabbitTemplate.setConfirmCallback(alarmConfirmCallBack);
    }


    @Override
    public String producerAlarmInfo(Map<String,Object> map) {
        CorrelationDataMessage correlationData = new CorrelationDataMessage();
        String msg = "发送一条告警消息";
        correlationData.setId(UUID.randomUUID().toString());
        correlationData.setMsg(map);
        correlationData.setExchangeName(EXCHANGE_NAME);
        correlationData.setRoutingKey(ALARM_ROUTING_KEY);
        rabbitTemplate.convertAndSend(EXCHANGE_NAME, ALARM_ROUTING_KEY,map,correlationData);
        System.out.println("msg = " + msg);
        return "告警成功";
    }

    @Override
    public String producerConfirmAlarmInfo(Map<String,Object> map) {
        String msg = "发送一条确认告警消息";
        rabbitTemplate.convertAndSend(EXCHANGE_NAME, CONFIRM_ALARM_ROUTING_KEY,map);
        System.out.println("msg = " + msg);
        return "告警成功";
    }
}
