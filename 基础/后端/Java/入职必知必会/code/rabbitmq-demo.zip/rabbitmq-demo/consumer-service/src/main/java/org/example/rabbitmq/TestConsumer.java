package org.example.rabbitmq;

import org.example.constant.RabbitMqConstant;
import org.example.service.IAlarmService;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

@Component
public class TestConsumer {

        @Autowired
        private IAlarmService alarmService;


        @RabbitListener(queues = RabbitMqConstant.QUEUE_NAME,concurrency = "5")
        public void getAlarmInfo(Message<?> message){
            alarmService.dealAlarmData(message);
        }

        @RabbitListener(queues =RabbitMqConstant.CONFIRM_ALARM_QUEUE_NAME,concurrency = "5")
        public void getConfirmAlarmInfo(Message<?> message){
            alarmService.dealConfirmAlarmData(message);
        }
}
