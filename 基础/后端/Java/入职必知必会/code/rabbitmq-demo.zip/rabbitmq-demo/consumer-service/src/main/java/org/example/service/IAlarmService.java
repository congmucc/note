package org.example.service;

import org.springframework.messaging.Message;

import java.util.Map;

public interface IAlarmService {
    void dealAlarmData(Message<?> message);

    void dealConfirmAlarmData(Message<?> message);
}
