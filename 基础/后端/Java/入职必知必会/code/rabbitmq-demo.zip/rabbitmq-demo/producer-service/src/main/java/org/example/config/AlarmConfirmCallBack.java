package org.example.config;

import lombok.extern.slf4j.Slf4j;
import org.example.domain.CorrelationDataMessage;
import org.springframework.amqp.rabbit.connection.CorrelationData;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class AlarmConfirmCallBack implements RabbitTemplate.ConfirmCallback {




    /**
     * correlationData  回调消息信息
     * ack 交换机是否收到消息  true表示收到
     * cause 交换机未收到消息的原因
     */
    @Override
    public void confirm(CorrelationData correlationData, boolean ack, String cause) {

        if (!ack) {
            CorrelationDataMessage correlationDataMessage = (CorrelationDataMessage) correlationData;
                //将消息入库，后续手动处理，或者定时去处理
                //................
            log.error("消息发送异常!，correlationData={} ,ack={}, cause={}", correlationData, ack, cause);
        } else {
            log.info("发送已经收到确认，correlationData={} ,ack={}, cause={}", correlationData, ack, cause);
        }
    }
}
