package org.example.service.impl;

import org.example.service.IAlarmService;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Service;

@Service
public class IAlarmServiceImpl implements IAlarmService {

    @Override
    public void dealAlarmData(Message<?> message) {
        //获取消息id
        String  messageId = String.valueOf(message.getHeaders().getId());
        //根据消息id去查询数据库或者redis,看是否存在，存在就不进行消费，不存在则进行消费，并存储消息id
        //获取消息内容
        Object messageInfo = message.getPayload();
        System.out.println("接收到的告警信息："+ messageInfo);
        System.out.println("接收到的告警信息ID："+ messageId);

       /* EquipAlarmResp equipAlarmResp= JSON.parseObject(result,EquipAlarmResp.class);
        List<String> alarmIdsOld = dceEquipAlarmMapper.queryAllAlarmIds();
        DceEquipAlarmDto dceEquipAlarmDto = CopyBeanUtils.copyProperties(equipAlarmResp, DceEquipAlarmDto.class);
        dceEquipAlarmDto.setCreateTime(new Date());
        dceEquipAlarmDto.setAlarmTime(dceEquipAlarmDto.getAlarmTime()/1000);
        //查询出需要新增或者更新的数据
        Boolean flag=alarmIdsOld.stream().filter(a->a.equals(dceEquipAlarmDto.getAlarmId())).findFirst().isPresent();
        //开启事务，保证新增、更新、删除的原子性
        TransactionStatus transaction = transactionManager.getTransaction(transactionDefinition);
        List<DceEquipAlarmDto> list=new ArrayList<>();
        list.add(dceEquipAlarmDto);
        try {
            //新增
            if (!flag) {
                dceEquipAlarmMapper.insertBatch(list);
            }
            //更新
            if (flag) {
                dceEquipAlarmMapper.updateBatch(list);
            }
            //提交事务
            transactionManager.commit(transaction);
        } catch (Exception e) {
            //回滚
            transactionManager.rollback(transaction);
            log.error("DynamicEnvironmentServiceImpl.getAlarmInfoByRabbitMq 新华报业动环设备告警信息更新失败！", e);
        }*/
    }

    @Override
    public void dealConfirmAlarmData(Message<?> message) {

        //获取消息id
        String  messageId = String.valueOf(message.getHeaders().getId());
        //根据消息id去查询数据库或者redis,看是否存在，存在就不进行消费，不存在则进行消费，并存储消息id
        //获取消息内容
        Object messageInfo = message.getPayload();
        System.out.println("接收到的告警信息："+ messageInfo);
       /* EquipConfirmAlarmResp alarmResp = JSON.parseObject(data,EquipConfirmAlarmResp.class);
        Integer confirmTime = Integer.parseInt(String.valueOf(System.currentTimeMillis() / 1000));
        alarmResp.setConfirmTime(confirmTime);
        dceEquipAlarmMapper.updateConfirmAlarmBatch(alarmResp,alarmResp.getAlarmIds());*/

    }



}
